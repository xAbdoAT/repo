//
//  CLPixellateEffect.h
//
//  Created by sho yakushiji on 2013/10/23.
//  Copyright (c) 2013年 CALACULU. All rights reserved.
//

#import "CLEffectBase.h"

@interface CLPixellateEffect : CLEffectBase

@end
