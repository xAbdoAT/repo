//
//  CLEmoticonTool.h
//
//  Created by Mokhlas Hussein on 01/02/14.
//  Copyright (c) 2014 iMokhles. All rights reserved.
//  CLImageEditor Author sho yakushiji.
//

#import "CLImageToolBase.h"

@interface CLEmoticonTool : CLImageToolBase

@end
