//
//  CLRotateTool.h
//
//  Created by sho yakushiji on 2013/11/08.
//  Copyright (c) 2013年 CALACULU. All rights reserved.
//

#import "CLImageToolBase.h"

@interface CLRotateTool : CLImageToolBase

@end
